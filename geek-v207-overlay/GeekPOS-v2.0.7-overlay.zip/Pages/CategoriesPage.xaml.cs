﻿using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using SweetsPOS.Core;
using Windows.Storage;
using Windows.Storage.Pickers;

namespace SweetsPOS.Pages;

public sealed partial class CategoriesPage : Page
{
    private List<Category> _items = [];

    public CategoriesPage()
    {
        InitializeComponent();
        Loaded += async (_, _) => await RefreshAsync();
    }

    private async Task RefreshAsync()
    {
        _items = await App.Services.Catalog.GetCategoriesAsync(false);
        List.ItemsSource = _items;
    }

    private async void Add_Click(object sender, RoutedEventArgs e)
    {
        if (await EditAsync(new Category { IsActive = true, SortOrder = _items.Count + 1 }))
            await RefreshAsync();
    }

    private async void Edit_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && int.TryParse(b.Tag?.ToString(), out var id) &&
            _items.FirstOrDefault(x => x.Id == id) is { } c && await EditAsync(c))
            await RefreshAsync();
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button b || !int.TryParse(b.Tag?.ToString(), out var id)) return;
        var category = _items.FirstOrDefault(x => x.Id == id);
        if (category is null) return;
        var confirm = new ContentDialog
        {
            XamlRoot = XamlRoot, RequestedTheme = ElementTheme.Dark, FlowDirection = FlowDirection.RightToLeft,
            Title = "حذف القسم؟", Content = $"سيتم حذف قسم «{category.Name}». يجب ألا يحتوي القسم على أصناف.",
            PrimaryButtonText = "حذف", CloseButtonText = "إلغاء", DefaultButton = ContentDialogButton.Close
        };
        if (await confirm.ShowAsync() != ContentDialogResult.Primary) return;
        try
        {
            await App.Services.Catalog.DeleteCategoryAsync(id);
            await App.Services.Settings.SetAsync($"CategoryImage_{id}", "");
            await RefreshAsync();
        }
        catch (Exception ex) { await PageHelpers.MessageAsync(XamlRoot, "تعذر حذف القسم", ex.Message); }
    }

    private async Task<bool> EditAsync(Category source)
    {
        var name = new TextBox { Header = "اسم القسم", Text = source.Name };
        var order = new NumberBox { Header = "الترتيب", Value = source.SortOrder, Minimum = 0, SpinButtonPlacementMode = NumberBoxSpinButtonPlacementMode.Hidden };
        var active = new CheckBox { Content = "نشط", IsChecked = source.IsActive };
        var imagePath = new TextBox
        {
            Header = "صورة / أيقونة القسم",
            IsReadOnly = true,
            PlaceholderText = "اختياري — ارفع صورة PNG أو JPG"
        };
        if (source.Id > 0)
            imagePath.Text = await App.Services.Settings.GetAsync($"CategoryImage_{source.Id}", "");

        var choose = new Button { Content = "اختيار صورة", Style = (Style)Application.Current.Resources["SoftButtonStyle"] };
        var remove = new Button { Content = "إزالة", Style = (Style)Application.Current.Resources["DangerButtonStyle"] };
        choose.Click += async (_, _) =>
        {
            var picker = new FileOpenPicker();
            picker.FileTypeFilter.Add(".png"); picker.FileTypeFilter.Add(".jpg"); picker.FileTypeFilter.Add(".jpeg"); picker.FileTypeFilter.Add(".webp"); picker.FileTypeFilter.Add(".bmp");
            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(App.MainWindow);
            WinRT.Interop.InitializeWithWindow.Initialize(picker, hwnd);
            var file = await picker.PickSingleFileAsync();
            if (file is null) return;
            var dir = Path.Combine(App.Services.Database.AppDataDirectory, "CategoryAssets");
            Directory.CreateDirectory(dir);
            var folder = await StorageFolder.GetFolderFromPathAsync(dir);
            var ext = Path.GetExtension(file.Name).ToLowerInvariant();
            var copied = await file.CopyAsync(folder, $"section-{Guid.NewGuid():N}{ext}", NameCollisionOption.ReplaceExisting);
            imagePath.Text = copied.Path;
        };
        remove.Click += (_, _) => imagePath.Text = "";

        var imageButtons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        imageButtons.Children.Add(choose);
        imageButtons.Children.Add(remove);

        var panel = new StackPanel { Width = 390, Spacing = 10, FlowDirection = FlowDirection.RightToLeft };
        panel.Children.Add(name);
        panel.Children.Add(order);
        panel.Children.Add(imagePath);
        panel.Children.Add(imageButtons);
        panel.Children.Add(active);

        var d = new ContentDialog
        {
            XamlRoot = XamlRoot,
            RequestedTheme = ElementTheme.Dark,
            Title = source.Id == 0 ? "قسم جديد" : "تعديل القسم",
            Content = panel,
            PrimaryButtonText = "حفظ",
            CloseButtonText = "إلغاء",
            DefaultButton = ContentDialogButton.Primary,
            FlowDirection = FlowDirection.RightToLeft
        };
        if (await d.ShowAsync() != ContentDialogResult.Primary) return false;
        if (string.IsNullOrWhiteSpace(name.Text))
        {
            await PageHelpers.MessageAsync(XamlRoot, "القسم", "اسم القسم مطلوب.");
            return false;
        }

        var saved = await App.Services.Catalog.SaveCategoryAsync(new Category
        {
            Id = source.Id,
            Name = name.Text.Trim(),
            SortOrder = (int)PageHelpers.DecimalFrom(order),
            IsActive = active.IsChecked == true
        });
        await App.Services.Settings.SetAsync($"CategoryImage_{saved.Id}", imagePath.Text.Trim());
        return true;
    }
}
