﻿using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using SweetsPOS.Core;
using SweetsPOS.Models;
using Microsoft.UI.Xaml.Media.Imaging;
using Windows.Storage;
using System.Globalization;

namespace SweetsPOS.Pages;

public sealed partial class PosPage : Page
{
    private readonly List<CartLine> _cart = [];
    private List<Product> _products = [];
    private List<Product> _allProducts = [];
    private List<Category> _categories = [];
    private int? _categoryId;
    private readonly Dictionary<int, string> _categoryImages = [];

    public PosPage()
    {
        InitializeComponent();
        Loaded += PosPage_Loaded;
    }

    private async void PosPage_Loaded(object sender, RoutedEventArgs e)
    {
        _categories = await App.Services.Catalog.GetCategoriesAsync();
        _categoryId = _categories.FirstOrDefault()?.Id;
        var allSettings = await App.Services.Settings.GetAllAsync();
        foreach (var c in _categories) _categoryImages[c.Id] = allSettings.GetValueOrDefault($"CategoryImage_{c.Id}", "");
        await RenderCategoriesAsync();
        await ReloadProductsAsync();
        RefreshShiftState();
        RefreshCart();
        BarcodeBox.Focus(FocusState.Programmatic);
    }

    private void RefreshShiftState()
    {
        var shift = App.Services.Session.CurrentShift;
        ShiftBar.Severity = shift is null ? InfoBarSeverity.Warning : InfoBarSeverity.Success;
        ShiftBar.Message = shift is null ? "افتح وردية لبدء البيع" : $"وردية #{shift.Id} • مفتوحة";
        PayButton.IsEnabled = shift is not null;
    }

    private async Task ReloadProductsAsync()
    {
        _allProducts = await App.Services.Catalog.GetProductsAsync();
        ApplyProductFilter();
    }

    private void ApplyProductFilter()
    {
        IEnumerable<Product> query = _allProducts;
        if (_categoryId.HasValue) query = query.Where(x => x.CategoryId == _categoryId.Value);
        var search = SearchBox?.Text?.Trim();
        if (!string.IsNullOrWhiteSpace(search))
        {
            query = query.Where(x =>
                x.Name.Contains(search, StringComparison.CurrentCultureIgnoreCase) ||
                x.ArabicName.Contains(search, StringComparison.CurrentCultureIgnoreCase) ||
                (!string.IsNullOrWhiteSpace(x.Barcode) && x.Barcode.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                (!string.IsNullOrWhiteSpace(x.Sku) && x.Sku.Contains(search, StringComparison.OrdinalIgnoreCase)));
        }
        _products = query.ToList();
        ProductsGrid.ItemsSource = _products;
    }

    private async Task RenderCategoriesAsync()
    {
        CategoriesPanel.Children.Clear();
        var normal = (Style)Application.Current.Resources["CategoryButtonStyle"];
        var active = (Style)Application.Current.Resources["CategoryButtonActiveStyle"];
        foreach (var category in _categories)
        {
            // Keep the section icon and name together on the RIGHT side of the button.
            // Do not rely on RTL Grid column mirroring here; it pushed the Arabic name to the left.
            var row = new Grid
            {
                ColumnSpacing = 9,
                FlowDirection = FlowDirection.LeftToRight,
                HorizontalAlignment = HorizontalAlignment.Stretch
            };
            // Star column absorbs all free space on the LEFT.
            // Name + icon are pinned together on the RIGHT edge.
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(32) });

            FrameworkElement icon;
            var path = _categoryImages.GetValueOrDefault(category.Id, "");
            if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
            {
                try
                {
                    var file = await StorageFile.GetFileFromPathAsync(path);
                    using var stream = await file.OpenReadAsync();
                    var bmp = new BitmapImage();
                    await bmp.SetSourceAsync(stream);
                    icon = new Image { Source = bmp, Width = 28, Height = 28, Stretch = Microsoft.UI.Xaml.Media.Stretch.UniformToFill, HorizontalAlignment = HorizontalAlignment.Center };
                }
                catch
                {
                    icon = new TextBlock { Text = "📁", FontSize = 18, HorizontalAlignment = HorizontalAlignment.Center };
                }
            }
            else
            {
                icon = new TextBlock { Text = "📁", FontSize = 18, HorizontalAlignment = HorizontalAlignment.Center };
            }
            Grid.SetColumn(icon, 2);
            row.Children.Add(icon);

            var name = new TextBlock
            {
                Text = category.Name,
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                TextAlignment = TextAlignment.Right,
                FlowDirection = FlowDirection.RightToLeft
            };
            Grid.SetColumn(name, 1);
            row.Children.Add(name);

            var button = new Button
            {
                Content = row,
                Tag = category.Id,
                Style = category.Id == _categoryId ? active : normal,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                FlowDirection = FlowDirection.RightToLeft
            };
            button.Click += Category_Click;
            CategoriesPanel.Children.Add(button);
        }
    }

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyProductFilter();

    private async void Category_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && int.TryParse(b.Tag?.ToString(), out var id))
        {
            _categoryId = id;
            await RenderCategoriesAsync();
            ApplyProductFilter();
        }
    }

    private async void Product_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button b || !int.TryParse(b.Tag?.ToString(), out var id)) return;
        var product = _products.FirstOrDefault(x => x.Id == id);
        if (product is not null) await AddProductInteractiveAsync(product);
    }

    private async Task AddProductInteractiveAsync(Product product)
    {
        decimal quantity = 1;
        if (product.SellUnit is SellUnit.Kg or SellUnit.Gram)
        {
            var isKg = product.SellUnit == SellUnit.Kg;
            var box = new TextBox
            {
                Header = isKg ? "الوزن (كجم)" : "الوزن (جرام)",
                Text = isKg ? "0.5" : "500",
                FlowDirection = FlowDirection.LeftToRight,
                TextAlignment = TextAlignment.Right,
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                InputScope = new InputScope { Names = { new InputScopeName(InputScopeNameValue.Number) } }
            };
            var presets = new Grid { ColumnSpacing = 7, FlowDirection = FlowDirection.RightToLeft, HorizontalAlignment = HorizontalAlignment.Stretch };
            for (var i = 0; i < 4; i++) presets.ColumnDefinitions.Add(new ColumnDefinition());
            var presetValues = isKg ? new[] { "0.5", "1", "1.5", "2" } : new[] { "500", "1000", "1500", "2000" };
            var presetLabels = new[] { "نصف كيلو", "1 كيلو", "1.5 كيلو", "2 كيلو" };
            for (var i = 0; i < presetValues.Length; i++)
            {
                var value = presetValues[i];
                var quick = new Button { Content = presetLabels[i], HorizontalAlignment = HorizontalAlignment.Stretch, Style = (Style)Application.Current.Resources["SoftButtonStyle"] };
                quick.Click += (_, _) => box.Text = value;
                Grid.SetColumn(quick, i);
                presets.Children.Add(quick);
            }
            var panel = new StackPanel { Width = 390, Spacing = 10, FlowDirection = FlowDirection.RightToLeft };
            panel.Children.Add(new TextBlock { Text = string.IsNullOrWhiteSpace(product.ArabicName) ? product.Name : product.ArabicName, FontSize = 20, FontWeight = Microsoft.UI.Text.FontWeights.Bold, TextAlignment = TextAlignment.Right, HorizontalAlignment = HorizontalAlignment.Stretch, FlowDirection = FlowDirection.RightToLeft });
            panel.Children.Add(box);
            panel.Children.Add(presets);
            var dialog = new ContentDialog
            {
                XamlRoot = XamlRoot, RequestedTheme = ElementTheme.Dark, FlowDirection = FlowDirection.RightToLeft,
                Title = "تحديد الكمية", Content = panel, PrimaryButtonText = "إضافة", CloseButtonText = "إلغاء", DefaultButton = ContentDialogButton.Primary
            };
            if (await dialog.ShowAsync() != ContentDialogResult.Primary) return;
            if (!TryDecimalFromText(box.Text, out quantity) || quantity <= 0) return;
        }
        AddToCart(product, quantity);
    }

    private void AddToCart(Product product, decimal quantity)
    {
        var existing = _cart.FirstOrDefault(x => x.ProductId == product.Id && x.UnitPrice == product.Price);
        if (existing is not null) existing.Quantity += quantity;
        else _cart.Add(new CartLine { ProductId = product.Id, Name = string.IsNullOrWhiteSpace(product.ArabicName) ? product.Name : product.ArabicName, SellUnit = product.SellUnit, Quantity = quantity, UnitPrice = product.Price });
        RefreshCart();
    }

    private void RefreshCart()
    {
        CartList.ItemsSource = null;
        CartList.ItemsSource = _cart;
        var subtotal = _cart.Sum(x => x.Total);
        var discount = PageHelpers.DecimalFrom(DiscountBox);
        if (discount > subtotal) discount = subtotal;
        SubtotalText.Text = $"{subtotal:0.00}";
        TotalText.Text = $"{Math.Max(0, subtotal - discount):0.00}";
        PayButton.Content = $"ادفع {Math.Max(0, subtotal - discount):0.00}";
    }

    private decimal IncrementFor(CartLine line) => line.SellUnit switch { SellUnit.Kg => 0.25m, SellUnit.Gram => 100m, _ => 1m };

    private void Plus_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && int.TryParse(b.Tag?.ToString(), out var id) && _cart.FirstOrDefault(x => x.ProductId == id) is { } line)
        {
            line.Quantity += IncrementFor(line);
            RefreshCart();
        }
    }

    private void Minus_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && int.TryParse(b.Tag?.ToString(), out var id) && _cart.FirstOrDefault(x => x.ProductId == id) is { } line)
        {
            line.Quantity -= IncrementFor(line);
            if (line.Quantity <= 0) _cart.Remove(line);
            RefreshCart();
        }
    }

    private void Remove_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && int.TryParse(b.Tag?.ToString(), out var id))
        {
            var line = _cart.FirstOrDefault(x => x.ProductId == id);
            if (line is not null) _cart.Remove(line);
            RefreshCart();
        }
    }

    private static bool TryDecimalFromText(string? text, out decimal value)
    {
        text = (text ?? string.Empty).Trim();
        if (decimal.TryParse(text, NumberStyles.Number, CultureInfo.CurrentCulture, out value)) return true;
        if (decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out value)) return true;
        value = 0;
        return false;
    }

    private static decimal DecimalFromLive(TextBox box)
        => TryDecimalFromText(box.Text, out var value) ? value : 0m;

    private void CommitQuantity(TextBox box)
    {
        if (!int.TryParse(box.Tag?.ToString(), out var id)) return;
        var line = _cart.FirstOrDefault(x => x.ProductId == id);
        if (line is null) return;
        if (!TryDecimalFromText(box.Text, out var qty) || qty <= 0)
        {
            box.Text = line.Quantity.ToString("0.###", CultureInfo.CurrentCulture);
            return;
        }
        if (line.Quantity == qty) return;
        line.Quantity = qty;
        RefreshCart();
    }

    private void QuantityBox_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key != Windows.System.VirtualKey.Enter || sender is not TextBox box) return;
        e.Handled = true;
        CommitQuantity(box);
    }

    private void QuantityBox_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox box) CommitQuantity(box);
    }

    private void DiscountBox_ValueChanged(NumberBox sender, NumberBoxValueChangedEventArgs args) => RefreshCart();

    private async void Pay_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (_cart.Count == 0) return;
            RefreshShiftState();
            if (App.Services.Session.CurrentShift is null)
            {
                await PageHelpers.MessageAsync(XamlRoot, "الوردية مطلوبة", "افتح وردية قبل إتمام البيع.");
                return;
            }

            var subtotal = _cart.Sum(x => x.Total);
            var discount = PageHelpers.DecimalFrom(DiscountBox);
            if (discount > subtotal) throw new InvalidOperationException("الخصم لا يمكن أن يكون أكبر من المجموع الفرعي.");
            var maxPct = await App.Services.Settings.GetDecimalAsync("MaxCashierDiscountPercent", 5);
            var pct = subtotal == 0 ? 0 : discount / subtotal * 100m;
            var overrideApproved = false;
            if (discount > 0 && string.IsNullOrWhiteSpace(DiscountReasonBox.Text))
                throw new InvalidOperationException("أدخل سبب الخصم.");
            if (pct > maxPct && !App.Services.Session.Can(Permission.DiscountOverride))
                overrideApproved = await AskApprovalAsync(Permission.DiscountOverride, $"خصم {pct:0.##}% يحتاج موافقة مشرف أو أدمن.");
            if (pct > maxPct && !App.Services.Session.Can(Permission.DiscountOverride) && !overrideApproved) return;

            var taxEnabled = await App.Services.Settings.GetBoolAsync("TaxEnabled");
            var taxPct = taxEnabled ? await App.Services.Settings.GetDecimalAsync("TaxPercent") : 0;
            var beforeTax = subtotal - discount;
            var tax = Math.Round(beforeTax * taxPct / 100m, 2);
            var total = Math.Round(beforeTax + tax, 2);
            var payResult = await AskPaymentsAsync(total);
            if (payResult is null) return;

            var sale = await App.Services.Sales.CompleteSaleAsync(_cart.ToList(), payResult.Value.Payments, discount, DiscountReasonBox.Text, overrideApproved, payResult.Value.Tendered, payResult.Value.Change);
            var printResult = await App.Services.Receipts.PrintSaleAsync(sale);
            var changeText = payResult.Value.Change > 0 ? $"\nالباقي: {payResult.Value.Change:0.00}" : "";
            await PageHelpers.MessageAsync(XamlRoot, $"الفاتورة #{sale.DisplayInvoiceNumber}", $"تم إتمام البيع بنجاح.{changeText}\nالإيصال: {printResult}");
            _cart.Clear();
            DiscountBox.Value = 0;
            DiscountReasonBox.Text = "";
            RefreshCart();
            await ReloadProductsAsync();
            BarcodeBox.Focus(FocusState.Programmatic);
        }
        catch (Exception ex)
        {
            await PageHelpers.MessageAsync(XamlRoot, "تعذر إتمام البيع", ex.Message);
        }
    }

    private async Task<bool> AskApprovalAsync(Permission permission, string message)
    {
        var pin = new PasswordBox { Header = "PIN المشرف / الأدمن", PasswordRevealMode = PasswordRevealMode.Peek };
        var stack = new StackPanel { Spacing = 10 };
        stack.Children.Add(new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap });
        stack.Children.Add(pin);
        var dialog = new ContentDialog { XamlRoot = XamlRoot, RequestedTheme = ElementTheme.Dark, Title = "موافقة مطلوبة", Content = stack, PrimaryButtonText = "موافقة", CloseButtonText = "إلغاء" };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return false;
        var approver = await App.Services.Auth.FindApproverAsync(pin.Password, permission);
        if (approver is null)
        {
            await PageHelpers.MessageAsync(XamlRoot, "فشلت الموافقة", "هذا الـ PIN غير مصرح له بهذه العملية.");
            return false;
        }
        await App.Services.Audit.WriteAsync("ApprovalGranted", "Permission", permission.ToString(), $"Approved {permission} for {App.Services.Session.CurrentUser?.DisplayName}", approver.Id, approver.DisplayName);
        return true;
    }

    private async Task<(List<PaymentInput> Payments, decimal Tendered, decimal Change)?> AskPaymentsAsync(decimal total)
    {
        var methods = await App.Services.PaymentMethods.GetActiveAsync();
        if (methods.Count == 0)
        {
            await PageHelpers.MessageAsync(XamlRoot, "طرق الدفع", "لا توجد طريقة دفع نشطة. فعّل طريقة دفع من لوحة الإدارة.");
            return null;
        }

        var boxes = new Dictionary<string, TextBox>(StringComparer.OrdinalIgnoreCase);
        var title = new TextBlock
        {
            Text = "الدفع", FontSize = 22, FontWeight = Microsoft.UI.Text.FontWeights.Bold,
            FlowDirection = FlowDirection.RightToLeft, TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var note = new TextBlock
        {
            Text = $"الإجمالي المطلوب: {total:0.00} جنيه",
            MaxWidth = 390, TextWrapping = TextWrapping.Wrap,
            FlowDirection = FlowDirection.RightToLeft, TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var balance = new TextBlock
        {
            Text = $"المتبقي: {total:0.00} جنيه",
            FontSize = 17, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            Foreground = (Microsoft.UI.Xaml.Media.Brush)Application.Current.Resources["AccentBrushSoft"],
            TextAlignment = TextAlignment.Center, HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var panel = new StackPanel { Spacing = 9, Width = 390, FlowDirection = FlowDirection.RightToLeft };
        panel.Children.Add(title);
        panel.Children.Add(note);
        panel.Children.Add(balance);

        foreach (var method in methods)
        {
            var box = new TextBox
            {
                Header = method.Name,
                Text = method.Key.Equals("cash", StringComparison.OrdinalIgnoreCase)
                    ? total.ToString("0.00", CultureInfo.CurrentCulture)
                    : "0",
                FlowDirection = FlowDirection.RightToLeft,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                TextAlignment = TextAlignment.Left
            };
            box.GotFocus += (_, _) => box.SelectAll();
            boxes[method.Key] = box;
            panel.Children.Add(box);
        }

        void RefreshBalance()
        {
            var tendered = boxes.Values.Sum(DecimalFromLive);
            var diff = tendered - total;
            if (diff > 0) balance.Text = $"الباقي للعميل: {diff:0.00} جنيه";
            else if (diff < 0) balance.Text = $"المتبقي: {-diff:0.00} جنيه";
            else balance.Text = "المبلغ مكتمل • الباقي: 0.00 جنيه";
        }

        foreach (var box in boxes.Values)
            box.TextChanged += (_, _) => RefreshBalance();

        RefreshBalance();

        var dialog = new ContentDialog
        {
            XamlRoot = XamlRoot, RequestedTheme = ElementTheme.Dark, Content = panel,
            PrimaryButtonText = "إتمام البيع", CloseButtonText = "إلغاء",
            DefaultButton = ContentDialogButton.Primary, FlowDirection = FlowDirection.RightToLeft,
            HorizontalContentAlignment = HorizontalAlignment.Stretch
        };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return null;

        var tendered = boxes.Values.Sum(DecimalFromLive);
        if (tendered < total)
        {
            await PageHelpers.MessageAsync(XamlRoot, "الدفع غير مكتمل", $"المتبقي: {total - tendered:0.00} جنيه");
            return null;
        }

        var change = tendered - total;
        var cashEntered = boxes.TryGetValue("cash", out var cashBox) ? DecimalFromLive(cashBox) : 0;
        if (change > cashEntered)
        {
            await PageHelpers.MessageAsync(XamlRoot, "دفع غير صالح", "أي مبلغ زائد يجب أن يكون ضمن المبلغ المدفوع كاش حتى يمكن حساب الباقي للعميل.");
            return null;
        }

        var inputs = new List<PaymentInput>();
        foreach (var method in methods)
        {
            var amount = DecimalFromLive(boxes[method.Key]);
            if (method.Key.Equals("cash", StringComparison.OrdinalIgnoreCase)) amount -= change;
            if (amount <= 0) continue;
            inputs.Add(new PaymentInput(method.LegacyMethod, amount, method.Key, method.Name));
        }

        return (inputs, tendered, change);
    }

    private async void Hold_Click(object sender, RoutedEventArgs e)
    {
        if (_cart.Count == 0) return;
        var label = new TextBox { Header = "اسم الطلب (اختياري)", PlaceholderText = "مثال: اسم العميل" };
        var dialog = new ContentDialog { XamlRoot = XamlRoot, RequestedTheme = ElementTheme.Dark, Title = "تعليق الطلب", Content = label, PrimaryButtonText = "تعليق", CloseButtonText = "إلغاء" };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return;
        await App.Services.Sales.HoldAsync(_cart.ToList(), label.Text);
        _cart.Clear();
        RefreshCart();
    }

    private async void Held_Click(object sender, RoutedEventArgs e)
    {
        var orders = await App.Services.Sales.GetHeldOrdersAsync();
        if (orders.Count == 0) { await PageHelpers.MessageAsync(XamlRoot, "الطلبات المعلقة", "لا توجد طلبات معلقة."); return; }
        var combo = new ComboBox { Header = "طلب معلق", ItemsSource = orders, DisplayMemberPath = "Label", SelectedIndex = 0, HorizontalAlignment = HorizontalAlignment.Stretch };
        var dialog = new ContentDialog { XamlRoot = XamlRoot, RequestedTheme = ElementTheme.Dark, Title = "استرجاع طلب معلق", Content = combo, PrimaryButtonText = "استرجاع", CloseButtonText = "إلغاء" };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary || combo.SelectedItem is not HeldOrder order) return;
        if (_cart.Count > 0) { await PageHelpers.MessageAsync(XamlRoot, "الطلب الحالي", "قم بمسح أو تعليق الطلب الحالي قبل استرجاع طلب آخر."); return; }
        _cart.AddRange(await App.Services.Sales.ResumeHeldOrderAsync(order.Id));
        RefreshCart();
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        _cart.Clear();
        DiscountBox.Value = 0;
        DiscountReasonBox.Text = "";
        RefreshCart();
    }

    private async void BarcodeBox_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key != Windows.System.VirtualKey.Enter || string.IsNullOrWhiteSpace(BarcodeBox.Text)) return;
        var product = await App.Services.Catalog.FindByBarcodeAsync(BarcodeBox.Text.Trim());
        if (product is null) await PageHelpers.MessageAsync(XamlRoot, "الباركود", "المنتج غير موجود.");
        else await AddProductInteractiveAsync(product);
        BarcodeBox.Text = "";
    }
}
