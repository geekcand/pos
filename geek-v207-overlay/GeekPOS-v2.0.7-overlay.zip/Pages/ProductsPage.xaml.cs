﻿using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using SweetsPOS.Core;

namespace SweetsPOS.Pages;

public sealed partial class ProductsPage : Page
{
    private List<Product> _products = [];
    private List<Product> _allProducts = [];
    public ProductsPage() { InitializeComponent(); Loaded += ProductsPage_Loaded; }
    private async void ProductsPage_Loaded(object sender, RoutedEventArgs e) => await ReloadAsync();

    private async Task ReloadAsync()
    {
        _allProducts = await App.Services.Catalog.GetProductsAsync(null, null, activeOnly: false);
        ApplyFilter();
    }

    private void ApplyFilter()
    {
        var search = SearchBox.Text?.Trim();
        IEnumerable<Product> query = _allProducts;
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(x => x.ArabicName.Contains(search, StringComparison.CurrentCultureIgnoreCase) || x.Name.Contains(search, StringComparison.CurrentCultureIgnoreCase) || (!string.IsNullOrWhiteSpace(x.Sku) && x.Sku.Contains(search, StringComparison.OrdinalIgnoreCase)) || (!string.IsNullOrWhiteSpace(x.Barcode) && x.Barcode.Contains(search, StringComparison.OrdinalIgnoreCase)));
        _products = query.ToList();
        ProductsList.ItemsSource = _products;
    }

    private void Search_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilter();
    private async void Add_Click(object sender, RoutedEventArgs e) { if (await EditProductAsync(new Product { IsActive = true, SellUnit = SellUnit.Piece })) await ReloadAsync(); }
    private async void Edit_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && int.TryParse(b.Tag?.ToString(), out var id) && _products.FirstOrDefault(x => x.Id == id) is { } p)
            if (await EditProductAsync(p)) await ReloadAsync();
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button b || !int.TryParse(b.Tag?.ToString(), out var id)) return;
        var product = _products.FirstOrDefault(x => x.Id == id);
        if (product is null) return;
        var confirm = new ContentDialog
        {
            XamlRoot = XamlRoot, RequestedTheme = ElementTheme.Dark, FlowDirection = FlowDirection.RightToLeft,
            Title = "حذف الصنف؟", Content = $"سيتم حذف «{product.ArabicName}» نهائيًا إذا لم يكن مستخدمًا في فواتير سابقة.",
            PrimaryButtonText = "حذف", CloseButtonText = "إلغاء", DefaultButton = ContentDialogButton.Close
        };
        if (await confirm.ShowAsync() != ContentDialogResult.Primary) return;
        try { await App.Services.Catalog.DeleteProductAsync(id); await ReloadAsync(); }
        catch (Exception ex) { await PageHelpers.MessageAsync(XamlRoot, "تعذر حذف الصنف", ex.Message); }
    }

    private async Task<bool> EditProductAsync(Product source)
    {
        var categories = await App.Services.Catalog.GetCategoriesAsync(activeOnly: false);
        var ar = new TextBox { Header = "اسم الصنف", Text = string.IsNullOrWhiteSpace(source.ArabicName) ? source.Name : source.ArabicName };
        var category = new ComboBox { Header = "التصنيف", ItemsSource = categories, DisplayMemberPath = "Name", HorizontalAlignment = HorizontalAlignment.Stretch };
        category.SelectedItem = categories.FirstOrDefault(x => x.Id == source.CategoryId) ?? categories.FirstOrDefault();
        var unit = new ComboBox { Header = "وحدة البيع", HorizontalAlignment = HorizontalAlignment.Stretch };
        foreach (var item in new[]
        {
            (SellUnit.Piece, "قطعة"), (SellUnit.Kg, "كجم"), (SellUnit.Gram, "جرام"), (SellUnit.Box, "علبة"), (SellUnit.Pack, "باك")
        })
        {
            var option = new ComboBoxItem { Content = item.Item2, Tag = item.Item1 };
            unit.Items.Add(option);
            if (item.Item1 == source.SellUnit) unit.SelectedItem = option;
        }
        var price = new NumberBox { Header = "السعر", Minimum = 0, Value = (double)source.Price, SpinButtonPlacementMode = NumberBoxSpinButtonPlacementMode.Hidden };
        var cost = new NumberBox { Header = "التكلفة", Minimum = 0, Value = (double)source.Cost, SpinButtonPlacementMode = NumberBoxSpinButtonPlacementMode.Hidden };
        var sku = new TextBox { Header = "كود الصنف (SKU)", Text = source.Sku ?? "" };
        var barcode = new TextBox { Header = "الباركود", Text = source.Barcode ?? "" };
        var imagePath = new TextBox { Header = "صورة الصنف", Text = source.ImagePath ?? "", IsReadOnly = true };
        var browseImage = new Button { Content = "اختيار صورة..." };
        browseImage.Click += async (_, _) =>
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.FileTypeFilter.Add(".png"); picker.FileTypeFilter.Add(".jpg"); picker.FileTypeFilter.Add(".jpeg"); picker.FileTypeFilter.Add(".webp");
            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(App.MainWindow);
            WinRT.Interop.InitializeWithWindow.Initialize(picker, hwnd);
            var file = await picker.PickSingleFileAsync();
            if (file is not null) imagePath.Text = new Uri(file.Path).AbsoluteUri;
        };
        browseImage.Style = (Style)Application.Current.Resources["SoftButtonStyle"];
        var imagePanel = new Grid { ColumnSpacing = 8 };
        imagePanel.ColumnDefinitions.Add(new ColumnDefinition());
        imagePanel.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        imagePanel.Children.Add(imagePath);
        Grid.SetColumn(browseImage, 1);
        browseImage.VerticalAlignment = VerticalAlignment.Bottom;
        imagePanel.Children.Add(browseImage);
        var stock = new NumberBox { Header = "المخزون الحالي", Minimum = 0, Value = (double)source.StockQuantity, SpinButtonPlacementMode = NumberBoxSpinButtonPlacementMode.Hidden };
        var low = new NumberBox { Header = "حد التنبيه للمخزون", Minimum = 0, Value = (double)source.LowStockLimit, SpinButtonPlacementMode = NumberBoxSpinButtonPlacementMode.Hidden };
        var track = new CheckBox { Content = "متابعة المخزون", IsChecked = source.TrackStock };
        var unlimited = new CheckBox { Content = "غير محدد بكمية", IsChecked = !source.TrackStock };
        track.Checked += (_, _) => unlimited.IsChecked = false;
        unlimited.Checked += (_, _) => track.IsChecked = false;
        var active = new CheckBox { Content = "متاح للبيع", IsChecked = source.IsActive };

        var panel = new Grid { Width = 500, ColumnSpacing = 10, RowSpacing = 12, FlowDirection = FlowDirection.RightToLeft };
        panel.ColumnDefinitions.Add(new ColumnDefinition());
        panel.ColumnDefinitions.Add(new ColumnDefinition());
        for (var i = 0; i < 6; i++) panel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        void Add(Control control, int row, int column, int span = 1)
        {
            Grid.SetRow(control, row); Grid.SetColumn(control, column); Grid.SetColumnSpan(control, span); panel.Children.Add(control);
        }
        Add(ar, 0, 0); Add(category, 0, 1);
        Add(unit, 1, 0); Add(price, 1, 1);
        Add(cost, 2, 0); Add(stock, 2, 1);
        Add(low, 3, 0); Add(sku, 3, 1);
        Add(barcode, 4, 0); Grid.SetRow(imagePanel, 4); Grid.SetColumn(imagePanel, 1); panel.Children.Add(imagePanel);
        var flags = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 22, Margin = new Thickness(2, 8, 2, 0) };
        flags.Children.Add(active); flags.Children.Add(track); flags.Children.Add(unlimited);
        Grid.SetRow(flags, 5); Grid.SetColumn(flags, 0); Grid.SetColumnSpan(flags, 2); panel.Children.Add(flags);

        var dialog = new ContentDialog
        {
            XamlRoot = XamlRoot,
            RequestedTheme = ElementTheme.Dark,
            Title = source.Id == 0 ? "صنف جديد" : "تعديل الصنف",
            Content = new ScrollViewer { Content = panel, MaxHeight = 590, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled },
            PrimaryButtonText = "حفظ",
            CloseButtonText = "إلغاء",
            DefaultButton = ContentDialogButton.Primary
        };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return false;
        try
        {
            if (category.SelectedItem is not Category cat) throw new InvalidOperationException("اختر تصنيفًا.");
            if (string.IsNullOrWhiteSpace(ar.Text)) throw new InvalidOperationException("اسم الصنف مطلوب.");
            var p = new Product
            {
                Id = source.Id, Name = ar.Text.Trim(), ArabicName = ar.Text.Trim(), CategoryId = cat.Id,
                SellUnit = unit.SelectedItem is ComboBoxItem unitItem && unitItem.Tag is SellUnit su ? su : SellUnit.Piece,
                Price = PageHelpers.DecimalFrom(price), Cost = PageHelpers.DecimalFrom(cost), Sku = string.IsNullOrWhiteSpace(sku.Text) ? null : sku.Text.Trim(),
                Barcode = string.IsNullOrWhiteSpace(barcode.Text) ? null : barcode.Text.Trim(), TrackStock = unlimited.IsChecked == true ? false : track.IsChecked == true,
                StockQuantity = PageHelpers.DecimalFrom(stock), LowStockLimit = PageHelpers.DecimalFrom(low), IsActive = active.IsChecked == true, ImagePath = string.IsNullOrWhiteSpace(imagePath.Text) ? null : imagePath.Text
            };
            await App.Services.Catalog.SaveProductAsync(p);
            return true;
        }
        catch (Exception ex) { await PageHelpers.MessageAsync(XamlRoot, "تعذر حفظ الصنف", ex.Message); return false; }
    }
}

