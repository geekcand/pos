﻿using Microsoft.EntityFrameworkCore;
using SweetsPOS.Core;
using SweetsPOS.Data;

namespace SweetsPOS.Services;

public sealed class CatalogService(DatabaseService database, AuditService audit)
{
    public async Task<List<Category>> GetCategoriesAsync(bool activeOnly = true)
    {
        await using var db = database.CreateContext();
        var q = db.Categories.AsNoTracking().AsQueryable();
        if (activeOnly) q = q.Where(x => x.IsActive);
        return await q.OrderBy(x => x.SortOrder).ThenBy(x => x.Name).ToListAsync();
    }

    public async Task<List<Product>> GetProductsAsync(int? categoryId = null, string? search = null, bool activeOnly = true)
    {
        await using var db = database.CreateContext();
        var q = db.Products.AsNoTracking().Include(x => x.Category).AsQueryable();
        if (activeOnly) q = q.Where(x => x.IsActive);
        if (categoryId.HasValue) q = q.Where(x => x.CategoryId == categoryId.Value);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            q = q.Where(x => x.Name.Contains(s) || x.ArabicName.Contains(s) || (x.Barcode != null && x.Barcode.Contains(s)) || (x.Sku != null && x.Sku.Contains(s)));
        }
        return await q.OrderBy(x => x.Category!.SortOrder).ThenBy(x => x.ArabicName).ToListAsync();
    }

    public async Task<Product?> FindByBarcodeAsync(string barcode)
    {
        await using var db = database.CreateContext();
        return await db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.IsActive && x.Barcode == barcode);
    }

    public async Task<Product> SaveProductAsync(Product input)
    {
        await using var db = database.CreateContext();
        Product row;
        string details;
        if (input.Id == 0)
        {
            row = input;
            row.UpdatedAt = DateTime.Now;
            db.Products.Add(row);
            details = $"Created {row.ArabicName} at {row.Price:0.00}";
        }
        else
        {
            row = await db.Products.FirstAsync(x => x.Id == input.Id);
            var oldPrice = row.Price;
            var oldStock = row.StockQuantity;
            row.Name = input.Name;
            row.ArabicName = input.ArabicName;
            row.Sku = input.Sku;
            row.Barcode = input.Barcode;
            row.CategoryId = input.CategoryId;
            row.SellUnit = input.SellUnit;
            row.Price = input.Price;
            row.Cost = input.Cost;
            row.TrackStock = input.TrackStock;
            row.StockQuantity = input.StockQuantity;
            row.LowStockLimit = input.LowStockLimit;
            row.ImagePath = input.ImagePath;
            row.IsActive = input.IsActive;
            row.UpdatedAt = DateTime.Now;
            if (row.TrackStock && oldStock != row.StockQuantity)
            {
                db.StockMovements.Add(new StockMovement
                {
                    ProductId = row.Id, Type = StockMovementType.Adjustment, QuantityDelta = row.StockQuantity - oldStock,
                    ReferenceType = "ProductEdit", ReferenceId = row.Id.ToString(), Note = "Stock changed from product editor"
                });
            }
            details = oldPrice == row.Price ? $"Updated {row.ArabicName}" : $"Updated {row.ArabicName}; price {oldPrice:0.00} -> {row.Price:0.00}";
        }
        await db.SaveChangesAsync();
        await audit.WriteAsync(input.Id == 0 ? "ProductCreated" : "ProductUpdated", "Product", row.Id.ToString(), details);
        return row;
    }

    public async Task<Category> SaveCategoryAsync(Category input)
    {
        await using var db = database.CreateContext();
        Category row;
        if (input.Id == 0)
        {
            row = input;
            db.Categories.Add(row);
        }
        else
        {
            row = await db.Categories.FirstAsync(x => x.Id == input.Id);
            row.Name = input.Name;
            row.SortOrder = input.SortOrder;
            row.IsActive = input.IsActive;
        }
        await db.SaveChangesAsync();
        await audit.WriteAsync(input.Id == 0 ? "CategoryCreated" : "CategoryUpdated", "Category", row.Id.ToString(), row.Name);
        return row;
    }

    public async Task AdjustStockAsync(int productId, decimal newQuantity, string note)
    {
        await using var db = database.CreateContext();
        await using var tx = await db.Database.BeginTransactionAsync();
        var p = await db.Products.FirstAsync(x => x.Id == productId);
        var delta = newQuantity - p.StockQuantity;
        p.StockQuantity = newQuantity;
        db.StockMovements.Add(new StockMovement
        {
            ProductId = productId,
            Type = StockMovementType.Adjustment,
            QuantityDelta = delta,
            ReferenceType = "ManualAdjustment",
            ReferenceId = Guid.NewGuid().ToString("N"),
            Note = note
        });
        await db.SaveChangesAsync();
        await tx.CommitAsync();
        await audit.WriteAsync("StockAdjusted", "Product", productId.ToString(), $"Delta {delta:0.###}; New {newQuantity:0.###}; {note}");
    }
    public async Task DeleteProductAsync(int productId)
    {
        await using var db = database.CreateContext();
        var product = await db.Products.FirstOrDefaultAsync(x => x.Id == productId)
            ?? throw new InvalidOperationException("الصنف غير موجود.");

        if (await db.SaleItems.AnyAsync(x => x.ProductId == productId))
            throw new InvalidOperationException("لا يمكن حذف هذا الصنف لأنه مستخدم في فواتير سابقة. يمكنك جعله غير متاح للبيع للحفاظ على سجل المبيعات والمرتجعات.");
        if (await db.HeldOrderItems.AnyAsync(x => x.ProductId == productId))
            throw new InvalidOperationException("لا يمكن حذف الصنف لأنه موجود في طلب معلّق. احذف الطلب المعلّق أولاً.");

        var movements = await db.StockMovements.Where(x => x.ProductId == productId).ToListAsync();
        if (movements.Count > 0) db.StockMovements.RemoveRange(movements);
        db.Products.Remove(product);
        await db.SaveChangesAsync();
        await audit.WriteAsync("ProductDeleted", "Product", productId.ToString(), product.ArabicName);
    }

    public async Task DeleteCategoryAsync(int categoryId)
    {
        await using var db = database.CreateContext();
        var category = await db.Categories.FirstOrDefaultAsync(x => x.Id == categoryId)
            ?? throw new InvalidOperationException("القسم غير موجود.");
        if (await db.Products.AnyAsync(x => x.CategoryId == categoryId))
            throw new InvalidOperationException("لا يمكن حذف القسم لأن بداخله أصناف. انقل أو احذف الأصناف الموجودة في القسم أولاً.");

        db.Categories.Remove(category);
        await db.SaveChangesAsync();
        await audit.WriteAsync("CategoryDeleted", "Category", categoryId.ToString(), category.Name);
    }

}
