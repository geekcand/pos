﻿using System.Runtime.InteropServices;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Text;
using SweetsPOS.Core;
using SweetsPOS.Models;
using Windows.Graphics.Imaging;
using Windows.Storage;

namespace SweetsPOS.Services;

public sealed class ReceiptService(SettingsService settings)
{
    static ReceiptService() => Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

    public async Task<string> BuildSaleReceiptAsync(Sale sale, bool includeHeaderAndFooter = true)
    {
        var all = await settings.GetAllAsync();
        var currency = "جنيه";
        var width = ParseInt(all.GetValueOrDefault("ReceiptWidthChars"), 42, 32, 48);
        var showInvoice = ParseBool(all.GetValueOrDefault("ReceiptShowInvoiceNumber"), true);
        var showDate = ParseBool(all.GetValueOrDefault("ReceiptShowDate"), true);
        var showCashier = ParseBool(all.GetValueOrDefault("ReceiptShowCashier"), true);
        var showPayments = ParseBool(all.GetValueOrDefault("ReceiptShowPayments"), true);
        var separator = new string('-', width);

        var invoiceLabel = all.GetValueOrDefault("ReceiptInvoiceLabel", "رقم الفاتورة");
        var dateLabel = all.GetValueOrDefault("ReceiptDateLabel", "التاريخ");
        var cashierLabel = all.GetValueOrDefault("ReceiptCashierLabel", "الكاشير");
        var productLabel = all.GetValueOrDefault("ReceiptProductLabel", "المنتج");
        var qtyLabel = all.GetValueOrDefault("ReceiptQtyLabel", "الكمية");
        var unitPriceLabel = all.GetValueOrDefault("ReceiptUnitPriceLabel", "سعر الوحدة");
        var lineTotalLabel = all.GetValueOrDefault("ReceiptLineTotalLabel", "الإجمالي");
        var subtotalLabel = all.GetValueOrDefault("ReceiptSubtotalLabel", "المجموع الفرعي");
        var discountLabel = all.GetValueOrDefault("ReceiptDiscountLabel", "الخصم");
        var totalLabel = all.GetValueOrDefault("ReceiptTotalLabel", "الإجمالي");
        var paymentHeader = all.GetValueOrDefault("ReceiptPaymentLabel", "طريقة الدفع");

        var sb = new StringBuilder();
        if (includeHeaderAndFooter)
        {
            var title = all.GetValueOrDefault("ReceiptTitle", "فاتورة ضريبية مبسطة");
            if (!string.IsNullOrWhiteSpace(title)) sb.AppendLine(Center(title, width));
            sb.AppendLine(Center(all.GetValueOrDefault("StoreName", "اسم المؤسسة"), width));
            if (!string.IsNullOrWhiteSpace(all.GetValueOrDefault("ReceiptHeaderNote")))
                sb.AppendLine(Center(all["ReceiptHeaderNote"], width));
            if (!string.IsNullOrWhiteSpace(all.GetValueOrDefault("StorePhone")))
                sb.AppendLine(Center(all["StorePhone"], width));
            if (!string.IsNullOrWhiteSpace(all.GetValueOrDefault("StoreAddress")))
                sb.AppendLine(Center(all["StoreAddress"], width));
        }

        sb.AppendLine(separator);
        if (showInvoice) sb.AppendLine($"{invoiceLabel}: #{sale.DisplayInvoiceNumber}");
        if (showDate) sb.AppendLine($"{dateLabel}: {FormatDateTime(sale.CreatedAt)}");
        if (showCashier) sb.AppendLine($"{cashierLabel}: {sale.User?.DisplayName ?? App.Services.Session.CurrentUser?.DisplayName ?? "-"}");
        if (showInvoice || showDate || showCashier) sb.AppendLine(separator);

        sb.AppendLine($"{productLabel} | {qtyLabel} | {unitPriceLabel} | {lineTotalLabel}");
        foreach (var item in sale.Items)
        {
            sb.AppendLine(item.ProductName);
            sb.AppendLine($"  {item.Quantity:0.###} {UnitLabel(item.SellUnit)} | {item.UnitPrice:0.00} | {item.LineTotal:0.00}");
        }

        sb.AppendLine(separator);
        sb.AppendLine(RightPair(subtotalLabel, $"{sale.Subtotal:0.00} {currency}", width));
        if (sale.DiscountAmount > 0) sb.AppendLine(RightPair(discountLabel, $"-{sale.DiscountAmount:0.00} {currency}", width));
        if (sale.TaxAmount > 0) sb.AppendLine(RightPair("الضريبة", $"{sale.TaxAmount:0.00} {currency}", width));
        sb.AppendLine(RightPair(totalLabel, $"{sale.Total:0.00} {currency}", width));

        if (showPayments && sale.Payments.Count > 0)
        {
            sb.AppendLine(separator);
            sb.AppendLine(paymentHeader);
            foreach (var payment in sale.Payments)
                sb.AppendLine(RightPair(PaymentMethodService.LabelFor(payment), $"{payment.Amount:0.00} {currency}", width));
            if (sale.TenderedAmount > 0)
                sb.AppendLine(RightPair("المبلغ المستلم", $"{sale.TenderedAmount:0.00} {currency}", width));
            if (sale.ChangeAmount > 0)
                sb.AppendLine(RightPair("الباقي للعميل", $"{sale.ChangeAmount:0.00} {currency}", width));
        }

        if (includeHeaderAndFooter)
        {
            sb.AppendLine(separator);
            var footer = all.GetValueOrDefault("ReceiptFooter", "شكراً لزيارتكم");
            if (!string.IsNullOrWhiteSpace(footer)) sb.AppendLine(Center(footer, width));
            if (ParseBool(all.GetValueOrDefault("ReceiptShowBarcode"), false) && !string.IsNullOrWhiteSpace(all.GetValueOrDefault("ReceiptBarcodePath")))
            {
                sb.AppendLine("[[RECEIPT_BARCODE]]");
                var caption = all.GetValueOrDefault("ReceiptBarcodeCaption", "");
                if (!string.IsNullOrWhiteSpace(caption)) sb.AppendLine(Center(caption, width));
            }
        }
        sb.AppendLine();
        sb.AppendLine();
        return sb.ToString();
    }

    public async Task<string> BuildShiftClosingAsync(Shift shift, ShiftTotals totals)
    {
        var all = await settings.GetAllAsync();
        var currency = "جنيه";
        var sb = new StringBuilder();
        sb.AppendLine(Center(all.GetValueOrDefault("StoreName", "اسم المؤسسة")));
        sb.AppendLine(Center("تقرير إغلاق الوردية"));
        sb.AppendLine(new string('-', 42));
        sb.AppendLine($"رقم الوردية: #{shift.Id}");
        sb.AppendLine($"الكاشير: {shift.User?.DisplayName ?? App.Services.Session.CurrentUser?.DisplayName ?? "-"}");
        sb.AppendLine($"الفتح: {FormatDateTime(shift.OpenedAt)}");
        sb.AppendLine($"الإغلاق: {(shift.ClosedAt.HasValue ? FormatDateTime(shift.ClosedAt.Value) : "-")}");
        sb.AppendLine(new string('-', 42));
        sb.AppendLine(RightPair("إجمالي المبيعات", Money(totals.GrossSales, currency)));
        sb.AppendLine(RightPair("كاش", Money(totals.CashSales, currency)));
        sb.AppendLine(RightPair("كارت", Money(totals.CardSales, currency)));
        sb.AppendLine(RightPair("إنستاباي", Money(totals.InstaPaySales, currency)));
        sb.AppendLine(RightPair("محفظة", Money(totals.WalletSales, currency)));
        sb.AppendLine(RightPair("الخصومات", Money(totals.Discounts, currency)));
        sb.AppendLine(RightPair("المرتجعات", Money(totals.CashRefunds + totals.OtherRefunds, currency)));
        sb.AppendLine(RightPair("المصروفات", Money(totals.Expenses, currency)));
        sb.AppendLine(new string('-', 42));
        sb.AppendLine(RightPair("النقدية المتوقعة", Money(shift.ExpectedCash, currency)));
        sb.AppendLine(RightPair("النقدية الفعلية", Money(shift.ActualCash ?? 0, currency)));
        sb.AppendLine(RightPair("الفرق", Money(shift.Difference ?? 0, currency)));
        sb.AppendLine();
        sb.AppendLine();
        return sb.ToString();
    }

    public async Task<string> BuildDailyReportAsync(DateTime from, DateTime toExclusive, DashboardSummary summary, IReadOnlyCollection<TopProductRow> topProducts)
    {
        var all = await settings.GetAllAsync();
        var currency = "جنيه";
        var sb = new StringBuilder();
        sb.AppendLine(Center(all.GetValueOrDefault("StoreName", "اسم المؤسسة")));
        sb.AppendLine(Center("تقرير المبيعات اليومي"));
        sb.AppendLine(new string('-', 42));
        sb.AppendLine($"من: {from:dd/MM/yyyy}");
        sb.AppendLine($"إلى: {toExclusive.AddDays(-1):dd/MM/yyyy}");
        sb.AppendLine(new string('-', 42));
        sb.AppendLine(RightPair("إجمالي المبيعات", Money(summary.Sales, currency)));
        sb.AppendLine(RightPair("المرتجعات", Money(summary.Refunds, currency)));
        sb.AppendLine(RightPair("صافي المبيعات", Money(summary.NetSales, currency)));
        sb.AppendLine(RightPair("المصروفات", Money(summary.Expenses, currency)));
        sb.AppendLine(RightPair("الربح التقديري", Money(summary.EstimatedGrossProfit, currency)));
        sb.AppendLine(RightPair("عدد الفواتير", summary.Orders.ToString()));
        sb.AppendLine(new string('-', 42));
        sb.AppendLine(RightPair("كاش", Money(summary.Cash, currency)));
        sb.AppendLine(RightPair("كارت", Money(summary.Card, currency)));
        sb.AppendLine(RightPair("إنستاباي", Money(summary.InstaPay, currency)));
        sb.AppendLine(RightPair("محفظة", Money(summary.Wallet, currency)));
        if (topProducts.Count > 0)
        {
            sb.AppendLine(new string('-', 42));
            sb.AppendLine("أعلى المنتجات");
            foreach (var p in topProducts.Take(10))
                sb.AppendLine($"{p.ProductName} | {p.Quantity:0.###} | {p.Sales:0.00}");
        }
        sb.AppendLine();
        sb.AppendLine();
        return sb.ToString();
    }

    public async Task<string> PrintSaleAsync(Sale sale, bool copy = false)
    {
        var path = await RenderSaleReceiptImageAsync(sale, preview: false, copy);
        var printer = await settings.GetAsync("ReceiptPrinter");
        if (!string.IsNullOrWhiteSpace(printer))
        {
            try
            {
                using var bitmap = new Bitmap(path);
                var raster = BitmapToEscPos(bitmap);
                var output = new List<byte>(raster.Length + 40);
                output.AddRange(new byte[] { 0x1B, 0x40, 0x1B, 0x61, 0x01 });
                var autoOpenDrawer = await settings.GetBoolAsync("CashDrawerAutoOpen", true);
                var hasCashPayment = sale.Payments.Any(p => p.Method == PaymentMethod.Cash || p.MethodKey.Equals("cash", StringComparison.OrdinalIgnoreCase));
                if (autoOpenDrawer && hasCashPayment)
                    output.AddRange(CashDrawerKickCommand);
                output.AddRange(raster);
                output.AddRange(new byte[] { 0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x00 });
                RawPrinter.Send(printer, output.ToArray());
                return $"تمت الطباعة على {printer}";
            }
            catch
            {
                // Keep the rendered PNG as a safe fallback; completing a sale must never fail because of a printer.
            }
        }
        return path;
    }


    private static readonly byte[] CashDrawerKickCommand = [0x1B, 0x70, 0x00, 0x32, 0xFA];

    public async Task<string> PrintTestAsync()
    {
        var printer = await settings.GetAsync("ReceiptPrinter", "");
        if (string.IsNullOrWhiteSpace(printer))
            throw new InvalidOperationException("اختر الطابعة الحرارية في الإعدادات أولاً.");

        var text = $"Geek POS\nPrinter Test\n{DateTime.Now:dd/MM/yyyy HH:mm}\n\n\n";
        var output = new List<byte> { 0x1B, 0x40, 0x1B, 0x61, 0x01 };
        output.AddRange(Encoding.ASCII.GetBytes(text));
        output.AddRange(new byte[] { 0x1D, 0x56, 0x00 });
        RawPrinter.Send(printer, output.ToArray());
        return $"تم إرسال صفحة اختبار إلى {printer}";
    }

    public async Task<string> OpenCashDrawerAsync()
    {
        var printer = await settings.GetAsync("ReceiptPrinter", "");
        if (string.IsNullOrWhiteSpace(printer))
            throw new InvalidOperationException("حدد اسم الطابعة الحرارية في الإعدادات أولاً.");

        RawPrinter.Send(printer, new byte[] { 0x1B, 0x40, 0x1B, 0x70, 0x00, 0x32, 0xFA });
        return $"تم إرسال أمر فتح درج النقدية إلى {printer}";
    }
    public Task<string> RenderSaleReceiptPreviewAsync(Sale sale)
        => RenderSaleReceiptImageAsync(sale, preview: true, copy: false);

    private async Task<string> RenderSaleReceiptImageAsync(Sale sale, bool preview, bool copy)
    {
        var all = await settings.GetAllAsync();
        var currency = "جنيه";
        var showInvoice = ParseBool(all.GetValueOrDefault("ReceiptShowInvoiceNumber"), true);
        var showDate = ParseBool(all.GetValueOrDefault("ReceiptShowDate"), true);
        var showCashier = ParseBool(all.GetValueOrDefault("ReceiptShowCashier"), true);
        var showPayments = ParseBool(all.GetValueOrDefault("ReceiptShowPayments"), true);
        var showLogo = ParseBool(all.GetValueOrDefault("ReceiptShowLogo"), false);
        var showBarcode = ParseBool(all.GetValueOrDefault("ReceiptShowBarcode"), false);
        var logoPath = all.GetValueOrDefault("ReceiptLogoPath", "");
        var barcodePath = all.GetValueOrDefault("ReceiptBarcodePath", "");

        const int width = 576; // standard 80mm thermal width at 203dpi
        const int margin = 24;
        var estimated = 650 + sale.Items.Count * 52 + (showLogo ? 150 : 0) + (showBarcode ? 250 : 0) + Math.Max(0, sale.Payments.Count - 1) * 34;
        using var canvas = new Bitmap(width, Math.Max(estimated, 900), PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(canvas);
        g.Clear(Color.White);
        g.SmoothingMode = SmoothingMode.HighQuality;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

        using var black = new SolidBrush(Color.FromArgb(20, 20, 20));
        using var gray = new SolidBrush(Color.FromArgb(100, 100, 100));
        using var linePen = new Pen(Color.FromArgb(80, 80, 80), 1f);
        using var dashPen = new Pen(Color.FromArgb(110, 110, 110), 1f) { DashStyle = DashStyle.Dash };
        using var titleFont = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
        using var storeFont = new Font("Segoe UI", 28f, FontStyle.Bold, GraphicsUnit.Pixel);
        using var textFont = new Font("Segoe UI", 15f, FontStyle.Regular, GraphicsUnit.Pixel);
        using var smallFont = new Font("Segoe UI", 13f, FontStyle.Regular, GraphicsUnit.Pixel);
        using var tableFont = new Font("Segoe UI", 14f, FontStyle.Regular, GraphicsUnit.Pixel);
        using var tableBold = new Font("Segoe UI", 14f, FontStyle.Bold, GraphicsUnit.Pixel);
        using var totalFont = new Font("Segoe UI", 16f, FontStyle.Bold, GraphicsUnit.Pixel);

        float y = 22;
        var receiptTitle = all.GetValueOrDefault("ReceiptTitle", "فاتورة ضريبية مبسطة");
        if (!string.IsNullOrWhiteSpace(receiptTitle))
        {
            DrawCentered(g, receiptTitle, titleFont, gray, y, width);
            y += 28;
        }

        if (showLogo && !string.IsNullOrWhiteSpace(logoPath) && File.Exists(logoPath))
        {
            try
            {
                using var img = System.Drawing.Image.FromFile(logoPath);
                var maxW = Math.Clamp((int)await settings.GetDecimalAsync("ReceiptLogoWidthDots", 220), 96, 420);
                var scale = Math.Min(maxW / (float)img.Width, 115f / img.Height);
                var w = Math.Max(1, (int)(img.Width * scale));
                var h = Math.Max(1, (int)(img.Height * scale));
                g.DrawImage(img, new Rectangle((width - w) / 2, (int)y, w, h));
                y += h + 10;
            }
            catch { }
        }

        DrawCentered(g, all.GetValueOrDefault("StoreName", "اسم المؤسسة"), storeFont, black, y, width);
        y += 42;
        var headerLines = new[]
        {
            all.GetValueOrDefault("ReceiptHeaderNote", ""),
            all.GetValueOrDefault("StoreAddress", ""),
            all.GetValueOrDefault("StorePhone", "")
        }.Where(x => !string.IsNullOrWhiteSpace(x));
        foreach (var line in headerLines)
        {
            DrawCentered(g, line, smallFont, gray, y, width);
            y += 23;
        }
        if (copy)
        {
            DrawCentered(g, "نسخة من الفاتورة", tableBold, black, y, width);
            y += 26;
        }
        y += 5;
        g.DrawLine(linePen, margin, y, width - margin, y); y += 14;

        var invoiceLabel = all.GetValueOrDefault("ReceiptInvoiceLabel", "رقم الفاتورة");
        var dateLabel = all.GetValueOrDefault("ReceiptDateLabel", "التاريخ");
        var cashierLabel = all.GetValueOrDefault("ReceiptCashierLabel", "الكاشير");
        if (showInvoice)
        {
            var invoiceText = $"{invoiceLabel}: #{sale.DisplayInvoiceNumber}";
            var box = new RectangleF(150, y, width - 300, 34);
            g.DrawRectangle(dashPen, Rectangle.Round(box));
            DrawCentered(g, invoiceText, tableBold, black, y + 6, width);
            y += 48;
        }
        if (showDate)
        {
            DrawRtl(g, $"{dateLabel}: {FormatDateTime(sale.CreatedAt)}", smallFont, black, new RectangleF(margin, y, width - margin * 2, 25), StringAlignment.Near);
            y += 26;
        }
        if (showCashier)
        {
            DrawRtl(g, $"{cashierLabel}: {sale.User?.DisplayName ?? App.Services.Session.CurrentUser?.DisplayName ?? "-"}", smallFont, black, new RectangleF(margin, y, width - margin * 2, 25), StringAlignment.Near);
            y += 26;
        }
        y += 6;
        g.DrawLine(linePen, margin, y, width - margin, y); y += 8;

        var productLabel = all.GetValueOrDefault("ReceiptProductLabel", "المنتج");
        var qtyLabel = all.GetValueOrDefault("ReceiptQtyLabel", "الكمية");
        var unitPriceLabel = all.GetValueOrDefault("ReceiptUnitPriceLabel", "سعر الوحدة");
        var lineTotalLabel = all.GetValueOrDefault("ReceiptLineTotalLabel", "الإجمالي");
        const float totalX = margin, totalW = 105, priceW = 110, qtyW = 82, productW = 231;
        var priceX = totalX + totalW;
        var qtyX = priceX + priceW;
        var productX = qtyX + qtyW;
        DrawCell(g, lineTotalLabel, tableBold, black, new RectangleF(totalX, y, totalW, 30), false);
        DrawCell(g, unitPriceLabel, tableBold, black, new RectangleF(priceX, y, priceW, 30), false);
        DrawCell(g, qtyLabel, tableBold, black, new RectangleF(qtyX, y, qtyW, 30), false);
        DrawCell(g, productLabel, tableBold, black, new RectangleF(productX, y, productW, 30), true);
        y += 31;
        g.DrawLine(linePen, margin, y, width - margin, y); y += 4;

        foreach (var item in sale.Items)
        {
            var rowH = 42f;
            DrawCell(g, $"{item.LineTotal:0.00}", tableFont, black, new RectangleF(totalX, y, totalW, rowH), false);
            DrawCell(g, $"{item.UnitPrice:0.00}", tableFont, black, new RectangleF(priceX, y, priceW, rowH), false);
            DrawCell(g, $"{item.Quantity:0.###}", tableFont, black, new RectangleF(qtyX, y, qtyW, rowH), false);
            DrawCell(g, item.ProductName, tableFont, black, new RectangleF(productX, y, productW, rowH), true);
            y += rowH;
            g.DrawLine(Pens.Gainsboro, margin, y, width - margin, y);
        }
        y += 10;
        g.DrawLine(linePen, margin, y, width - margin, y); y += 12;

        var subtotalLabel = all.GetValueOrDefault("ReceiptSubtotalLabel", "السعر الإجمالي للمنتجات");
        var discountLabel = all.GetValueOrDefault("ReceiptDiscountLabel", "قيمة الخصم");
        var totalLabel = all.GetValueOrDefault("ReceiptTotalLabel", "الإجمالي بعد الخصم");
        DrawTotalRow(g, subtotalLabel, sale.Subtotal, currency, textFont, black, ref y, width, margin);
        if (sale.DiscountAmount > 0) DrawTotalRow(g, discountLabel, sale.DiscountAmount, currency, textFont, black, ref y, width, margin);
        if (sale.TaxAmount > 0) DrawTotalRow(g, "الضريبة", sale.TaxAmount, currency, textFont, black, ref y, width, margin);
        DrawTotalRow(g, totalLabel, sale.Total, currency, totalFont, black, ref y, width, margin);

        if (showPayments && sale.Payments.Count > 0)
        {
            y += 5; g.DrawLine(linePen, margin, y, width - margin, y); y += 10;
            var paymentHeader = all.GetValueOrDefault("ReceiptPaymentLabel", "طريقة الدفع");
            DrawRtl(g, paymentHeader, tableBold, black, new RectangleF(margin, y, width - margin * 2, 26), StringAlignment.Near); y += 28;
            foreach (var payment in sale.Payments)
                DrawTotalRow(g, PaymentMethodService.LabelFor(payment), payment.Amount, currency, textFont, black, ref y, width, margin);
            if (sale.TenderedAmount > 0)
                DrawTotalRow(g, "المبلغ المستلم", sale.TenderedAmount, currency, textFont, black, ref y, width, margin);
            if (sale.ChangeAmount > 0)
                DrawTotalRow(g, "الباقي للعميل", sale.ChangeAmount, currency, textFont, black, ref y, width, margin);
        }

        y += 8;
        var footer = all.GetValueOrDefault("ReceiptFooter", "شكراً لزيارتكم");
        if (!string.IsNullOrWhiteSpace(footer))
        {
            DrawCentered(g, footer, smallFont, gray, y, width); y += 28;
        }

        if (showBarcode && !string.IsNullOrWhiteSpace(barcodePath) && File.Exists(barcodePath))
        {
            try
            {
                using var img = System.Drawing.Image.FromFile(barcodePath);
                var maxW = Math.Clamp((int)await settings.GetDecimalAsync("ReceiptBarcodeWidthDots", 210), 96, 320);
                var scale = Math.Min(maxW / (float)img.Width, 210f / img.Height);
                var w = Math.Max(1, (int)(img.Width * scale));
                var h = Math.Max(1, (int)(img.Height * scale));
                g.DrawImage(img, new Rectangle((width - w) / 2, (int)y, w, h));
                y += h + 8;
                var caption = all.GetValueOrDefault("ReceiptBarcodeCaption", "");
                if (!string.IsNullOrWhiteSpace(caption)) { DrawCentered(g, caption, smallFont, gray, y, width); y += 24; }
            }
            catch { }
        }
        y += 20;

        var finalHeight = Math.Max(200, Math.Min(canvas.Height, (int)Math.Ceiling(y)));
        using var cropped = canvas.Clone(new Rectangle(0, 0, width, finalHeight), PixelFormat.Format32bppArgb);
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SweetsPOS", "Receipts");
        Directory.CreateDirectory(dir);
        var path = preview
            ? Path.Combine(dir, "receipt-preview.png")
            : Path.Combine(dir, $"invoice-{sale.InvoiceNumber}{(copy ? "-copy" : "")}-{DateTime.Now:yyyyMMdd-HHmmss}.png");
        cropped.Save(path, ImageFormat.Png);
        return path;
    }

    private static void DrawCentered(Graphics g, string text, Font font, Brush brush, float y, int width)
    {
        using var fmt = new StringFormat(StringFormatFlags.DirectionRightToLeft) { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Near };
        g.DrawString(text ?? "", font, brush, new RectangleF(16, y, width - 32, font.Height + 10), fmt);
    }

    private static void DrawRtl(Graphics g, string text, Font font, Brush brush, RectangleF rect, StringAlignment alignment)
    {
        using var fmt = new StringFormat(StringFormatFlags.DirectionRightToLeft)
        {
            Alignment = alignment,
            LineAlignment = StringAlignment.Center,
            Trimming = StringTrimming.EllipsisCharacter
        };
        g.DrawString(text ?? "", font, brush, rect, fmt);
    }

    private static void DrawCell(Graphics g, string text, Font font, Brush brush, RectangleF rect, bool rtl)
    {
        var flags = rtl ? StringFormatFlags.DirectionRightToLeft : StringFormatFlags.NoClip;
        using var fmt = new StringFormat(flags)
        {
            Alignment = rtl ? StringAlignment.Near : StringAlignment.Center,
            LineAlignment = StringAlignment.Center,
            Trimming = StringTrimming.EllipsisCharacter
        };
        g.DrawString(text ?? "", font, brush, rect, fmt);
    }

    private static void DrawTotalRow(Graphics g, string label, decimal amount, string currency, Font font, Brush brush, ref float y, int width, int margin)
    {
        DrawRtl(g, label, font, brush, new RectangleF(width / 2f - 10, y, width / 2f - margin + 10, 28), StringAlignment.Near);
        using var valueFmt = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center };
        g.DrawString($"{amount:0.00} {currency}", font, brush, new RectangleF(margin, y, width / 2f - margin - 5, 28), valueFmt);
        y += 30;
    }

    private static byte[] BitmapToEscPos(Bitmap bitmap)
    {
        var rowBytes = (bitmap.Width + 7) / 8;
        var data = new byte[rowBytes * bitmap.Height];
        for (var y = 0; y < bitmap.Height; y++)
        {
            for (var x = 0; x < bitmap.Width; x++)
            {
                var c = bitmap.GetPixel(x, y);
                var luminance = (c.R * 299 + c.G * 587 + c.B * 114) / 1000;
                if (luminance < 190)
                    data[y * rowBytes + x / 8] |= (byte)(0x80 >> (x % 8));
            }
        }
        var result = new List<byte>(data.Length + 12)
        {
            0x1D, 0x76, 0x30, 0x00,
            (byte)(rowBytes & 0xFF), (byte)((rowBytes >> 8) & 0xFF),
            (byte)(bitmap.Height & 0xFF), (byte)((bitmap.Height >> 8) & 0xFF)
        };
        result.AddRange(data);
        return result.ToArray();
    }

    public async Task<string> PrintOrSaveAsync(string receiptText, string prefix)
    {
        var printer = await settings.GetAsync("ReceiptPrinter");
        if (!string.IsNullOrWhiteSpace(printer))
        {
            try
            {
                var encodingName = await settings.GetAsync("ReceiptEncoding", "utf-8");
                var encoding = encodingName.Equals("utf-8", StringComparison.OrdinalIgnoreCase) ? Encoding.UTF8 : Encoding.GetEncoding(encodingName);
                var output = new List<byte>(encoding.GetByteCount(receiptText) + 8192);
                output.AddRange(new byte[] { 0x1B, 0x40 }); // ESC/POS initialize

                if (prefix.StartsWith("invoice-", StringComparison.OrdinalIgnoreCase))
                {
                    var logo = await BuildLogoRasterAsync();
                    if (logo is { Length: > 0 }) output.AddRange(logo);
                }

                const string barcodeMarker = "[[RECEIPT_BARCODE]]";
                var markerIndex = receiptText.IndexOf(barcodeMarker, StringComparison.Ordinal);
                if (markerIndex >= 0 && prefix.StartsWith("invoice-", StringComparison.OrdinalIgnoreCase))
                {
                    var before = receiptText[..markerIndex];
                    var after = receiptText[(markerIndex + barcodeMarker.Length)..];
                    output.AddRange(encoding.GetBytes(before));
                    var barcode = await BuildConfiguredRasterAsync("ReceiptShowBarcode", "ReceiptBarcodePath", "ReceiptBarcodeWidthDots", 240);
                    if (barcode is { Length: > 0 }) output.AddRange(barcode);
                    output.AddRange(encoding.GetBytes(after + "\n\n\n"));
                }
                else
                {
                    output.AddRange(encoding.GetBytes(receiptText + "\n\n\n"));
                }
                RawPrinter.Send(printer, output.ToArray());
                return $"تمت الطباعة على {printer}";
            }
            catch
            {
                // Fall through to file so a sale never fails because the printer is unavailable.
            }
        }

        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SweetsPOS", "Receipts");
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, $"{prefix}-{DateTime.Now:yyyyMMdd-HHmmss}.txt");
        await File.WriteAllTextAsync(path, receiptText, Encoding.UTF8);
        return path;
    }

    private Task<byte[]?> BuildLogoRasterAsync()
        => BuildConfiguredRasterAsync("ReceiptShowLogo", "ReceiptLogoPath", "ReceiptLogoWidthDots", 384);

    private async Task<byte[]?> BuildConfiguredRasterAsync(string showKey, string pathKey, string widthKey, int defaultWidth)
    {
        if (!await settings.GetBoolAsync(showKey, false)) return null;
        var path = await settings.GetAsync(pathKey, "");
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return null;

        var file = await StorageFile.GetFileFromPathAsync(path);
        using var stream = await file.OpenReadAsync();
        var decoder = await BitmapDecoder.CreateAsync(stream);
        if (decoder.PixelWidth == 0 || decoder.PixelHeight == 0) return null;

        var maxWidth = (uint)Math.Clamp((int)await settings.GetDecimalAsync(widthKey, defaultWidth), 96, 576);
        var scale = Math.Min(1d, maxWidth / (double)decoder.PixelWidth);
        var width = (uint)Math.Max(1, Math.Round(decoder.PixelWidth * scale));
        var height = (uint)Math.Max(1, Math.Round(decoder.PixelHeight * scale));
        var transform = new BitmapTransform
        {
            ScaledWidth = width,
            ScaledHeight = height,
            InterpolationMode = BitmapInterpolationMode.Fant
        };
        var provider = await decoder.GetPixelDataAsync(
            BitmapPixelFormat.Bgra8,
            BitmapAlphaMode.Ignore,
            transform,
            ExifOrientationMode.RespectExifOrientation,
            ColorManagementMode.DoNotColorManage);
        var pixels = provider.DetachPixelData();

        var rowBytes = (int)((width + 7) / 8);
        var data = new byte[rowBytes * (int)height];
        for (var y = 0; y < (int)height; y++)
        {
            for (var x = 0; x < (int)width; x++)
            {
                var index = (y * (int)width + x) * 4;
                var b = pixels[index];
                var g = pixels[index + 1];
                var r = pixels[index + 2];
                var luminance = (r * 299 + g * 587 + b * 114) / 1000;
                if (luminance < 180)
                    data[y * rowBytes + (x / 8)] |= (byte)(0x80 >> (x % 8));
            }
        }

        var result = new List<byte>(data.Length + 16);
        result.AddRange(new byte[] { 0x1B, 0x61, 0x01 }); // center
        result.AddRange(new byte[]
        {
            0x1D, 0x76, 0x30, 0x00,
            (byte)(rowBytes & 0xFF), (byte)((rowBytes >> 8) & 0xFF),
            (byte)(height & 0xFF), (byte)((height >> 8) & 0xFF)
        });
        result.AddRange(data);
        result.Add(0x0A);
        result.Add(0x0A);
        result.AddRange(new byte[] { 0x1B, 0x61, 0x00 }); // left/default
        return result.ToArray();
    }

    private static int ParseInt(string? text, int fallback, int min, int max)
        => int.TryParse(text, out var value) ? Math.Clamp(value, min, max) : fallback;

    private static bool ParseBool(string? text, bool fallback)
        => bool.TryParse(text, out var value) ? value : fallback;

    private static string UnitLabel(SellUnit unit) => unit switch
    {
        SellUnit.Kg => "كجم",
        SellUnit.Gram => "جرام",
        SellUnit.Box => "علبة",
        SellUnit.Pack => "باك",
        _ => "قطعة"
    };

    private static string FormatDateTime(DateTime value)
        => $"{value:dd/MM/yyyy hh:mm} {(value.Hour < 12 ? "صباحاً" : "مساءاً")}";

    private static string PaymentLabel(PaymentMethod method) => method switch
    {
        PaymentMethod.Cash => "كاش",
        PaymentMethod.Card => "كارت",
        PaymentMethod.InstaPay => "إنستاباي",
        PaymentMethod.Wallet => "محفظة",
        _ => method.ToString()
    };

    private static string Center(string text, int width = 42)
    {
        if (string.IsNullOrWhiteSpace(text)) return "";
        if (text.Length >= width) return text;
        return new string(' ', Math.Max(0, (width - text.Length) / 2)) + text;
    }

    private static string RightPair(string left, string right, int width = 42)
    {
        var spaces = Math.Max(1, width - left.Length - right.Length);
        return left + new string(' ', spaces) + right;
    }

    private static string Money(decimal amount, string currency) => $"{amount:0.00} {currency}";

    private static class RawPrinter
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private sealed class DOC_INFO_1
        {
            [MarshalAs(UnmanagedType.LPWStr)] public string pDocName = "Geek POS Receipt";
            [MarshalAs(UnmanagedType.LPWStr)] public string? pOutputFile;
            [MarshalAs(UnmanagedType.LPWStr)] public string pDataType = "RAW";
        }

        [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Unicode)] private static extern bool OpenPrinter(string pPrinterName, out IntPtr phPrinter, IntPtr pDefault);
        [DllImport("winspool.drv", SetLastError = true)] private static extern bool ClosePrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Unicode)] private static extern int StartDocPrinter(IntPtr hPrinter, int level, [In] DOC_INFO_1 di);
        [DllImport("winspool.drv", SetLastError = true)] private static extern bool EndDocPrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", SetLastError = true)] private static extern bool StartPagePrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", SetLastError = true)] private static extern bool EndPagePrinter(IntPtr hPrinter);
        [DllImport("winspool.drv", SetLastError = true)] private static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);

        public static void Send(string printerName, byte[] bytes)
        {
            if (!OpenPrinter(printerName, out var hPrinter, IntPtr.Zero)) throw new InvalidOperationException("Printer not found.");
            try
            {
                if (StartDocPrinter(hPrinter, 1, new DOC_INFO_1()) == 0) throw new InvalidOperationException("Could not start print job.");
                try
                {
                    if (!StartPagePrinter(hPrinter)) throw new InvalidOperationException("Could not start printer page.");
                    var unmanaged = Marshal.AllocCoTaskMem(bytes.Length);
                    try
                    {
                        Marshal.Copy(bytes, 0, unmanaged, bytes.Length);
                        if (!WritePrinter(hPrinter, unmanaged, bytes.Length, out var written) || written != bytes.Length)
                            throw new InvalidOperationException("Could not write complete receipt to printer.");
                    }
                    finally { Marshal.FreeCoTaskMem(unmanaged); }
                    EndPagePrinter(hPrinter);
                }
                finally { EndDocPrinter(hPrinter); }
            }
            finally { ClosePrinter(hPrinter); }
        }
    }
}
