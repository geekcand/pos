﻿#define MyAppName "Geek POS"
#define MyAppVersion "2.0.7"
#define MyAppExeName "App.exe"

[Setup]
AppId={{5CE7E944-6548-4B72-9AA8-2E2E14A22B6A}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=Geek POS
AppPublisherURL=mailto:a7medelzainy@gmail.com
VersionInfoCompany=Geek POS
VersionInfoDescription=Geek POS - Point of Sale System
VersionInfoProductName=Geek POS
VersionInfoProductVersion={#MyAppVersion}
DefaultDirName={localappdata}\Programs\Geek POS
UsePreviousAppDir=no
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=artifacts\installer-fixed
OutputBaseFilename=GeekPOS-Setup-x64-v2.0.7
SetupIconFile=Assets\GeekPOS.ico
Compression=lzma2/fast
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.19041
PrivilegesRequired=lowest
UninstallDisplayIcon={app}\Assets\GeekPOS.ico

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"
Name: "startup"; Description: "Start Geek POS when I sign in to Windows"; GroupDescription: "Startup:"

[Files]
Source: "artifacts\final-win-x64\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "InstallerTools\GeekPOS-Activate.ps1"; Flags: dontcopy

[Icons]
Name: "{userprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\GeekPOS.ico"
Name: "{userdesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\GeekPOS.ico"; Tasks: desktopicon
Name: "{userstartup}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\GeekPOS.ico"; Tasks: startup

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: files; Name: "{app}\activation.dat"

[Code]
var
  LicensePage: TInputQueryWizardPage;
  ActivationToken: String;
  InstallId: String;
  DeviceBinding: String;

function CmdQuote(const S: String): String;
begin
  Result := '"' + S + '"';
end;

function RunActivation(const Serial: String): Boolean;
var
  ScriptPath, OutputPath, PowerShellExe, Params, Response, Rest, Remaining: String;
  Raw: AnsiString;
  ResultCode, Sep, Sep2: Integer;
begin
  Result := False;
  ActivationToken := '';
  InstallId := '';
  DeviceBinding := '';

  ExtractTemporaryFile('GeekPOS-Activate.ps1');
  ScriptPath := ExpandConstant('{tmp}\GeekPOS-Activate.ps1');
  OutputPath := ExpandConstant('{tmp}\GeekPOS-Activate-result.txt');
  PowerShellExe := ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe');
  DeleteFile(OutputPath);

  Params := '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ' +
    CmdQuote(ScriptPath) + ' -Serial ' + CmdQuote(Uppercase(Trim(Serial))) +
    ' -OutFile ' + CmdQuote(OutputPath);

  if not Exec(PowerShellExe, Params, '', SW_HIDE, ewWaitUntilTerminated, ResultCode) then
  begin
    MsgBox('تعذر تشغيل خدمة التفعيل على Windows.', mbError, MB_OK);
    Exit;
  end;

  if not LoadStringFromFile(OutputPath, Raw) then
  begin
    MsgBox('لم يتم استلام رد من خدمة التفعيل. أعد المحاولة.', mbError, MB_OK);
    Exit;
  end;

  Response := Trim(String(Raw));

  if Copy(Response, 1, 3) = 'OK|' then
  begin
    Rest := Copy(Response, 4, Length(Response) - 3);
    Sep := Pos('|', Rest);
    if Sep <= 1 then
    begin
      MsgBox('رد التفعيل غير مكتمل.', mbError, MB_OK);
      Exit;
    end;

    ActivationToken := Copy(Rest, 1, Sep - 1);
    Remaining := Copy(Rest, Sep + 1, Length(Rest) - Sep);
    Sep2 := Pos('|', Remaining);
    if Sep2 <= 1 then
    begin
      MsgBox('رد التفعيل غير مكتمل.', mbError, MB_OK);
      Exit;
    end;
    InstallId := Copy(Remaining, 1, Sep2 - 1);
    DeviceBinding := Copy(Remaining, Sep2 + 1, Length(Remaining) - Sep2);

    if (Length(ActivationToken) > 20) and (Length(InstallId) > 10) and (Length(DeviceBinding) = 64) then
    begin
      Result := True;
      Exit;
    end;

    MsgBox('بيانات التفعيل المستلمة غير مكتملة.', mbError, MB_OK);
    Exit;
  end;

  if Response = 'ERR|REJECTED' then
    MsgBox('مفتاح التفعيل غير صحيح أو مستخدم بالفعل. إذا سبق استخدامه، اعمل له Reset ثم حاول مرة أخرى.', mbError, MB_OK)
  else if Response = 'ERR|FORMAT' then
    MsgBox('صيغة مفتاح التفعيل غير صحيحة.', mbError, MB_OK)
  else if Response = 'ERR|DEVICE' then
    MsgBox('تعذر قراءة هوية الجهاز.', mbError, MB_OK)
  else
    MsgBox('فشل الاتصال بخادم التفعيل. كود الخطأ: ' + Response, mbError, MB_OK);
end;

procedure InitializeWizard;
begin
  LicensePage := CreateInputQueryPage(
    wpWelcome,
    'تفعيل Geek POS',
    'مفتاح التفعيل الأصلي مطلوب',
    'أدخل License Key الذي حصلت عليه عند شراء Geek POS. المفتاح يعمل على جهاز وتثبيت واحد فقط.'
  );
  LicensePage.Add('License Key:', False);
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if CurPageID = LicensePage.ID then
  begin
    WizardForm.NextButton.Enabled := False;
    Result := RunActivation(LicensePage.Values[0]);
    WizardForm.NextButton.Enabled := True;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  State: AnsiString;
begin
  if CurStep = ssPostInstall then
  begin
    if (ActivationToken = '') or (InstallId = '') or (DeviceBinding = '') then
      RaiseException('Geek POS activation was not completed.');

    State := '{"ActivationToken":"' + ActivationToken +
      '","InstallId":"' + InstallId +
      '","DeviceBinding":"' + DeviceBinding + '"}';

    if not SaveStringToFile(ExpandConstant('{app}\activation.dat'), State, False) then
      RaiseException('Could not save Geek POS activation state.');
  end;
end;
